# Ekranların və İcazələrin Xəritəsi (Screen Map)

Aşağıda tətbiqin interfeys xəritəsi və kimlərin baxış / redaktə icazəsi olduğu göstərilir:

| Ekran | Route Path | İcazələr (View) | İcazələr (Edit/Create) |
|---|---|---|---|
| Dashboard | `/dashboard` | Bütün rollar | N/A |
| KPI Matrix Heatmap | `/dashboard/kpi` | Bütün rollar | N/A |
| Profile | `/profile` | Öz profili (Hər kəs) | Öz profili (Hər kəs) |
| Assets (Aktivlər) | `/assets` | Bütün rollar | Admin, DPO, İZOM |
| Threats (Təhdidlər) | `/threats` | Bütün rollar | Admin, İZOM_Mutexessis |
| Vulns. (Boşluqlar) | `/vulnerabilities`| Bütün rollar | Admin, İZOM_Mutexessis |
| Risk Registry | `/risks` | Bütün rollar | Admin, İZOM |
| Incidents | `/incidents` | Bütün rollar | Admin, İZOM |
| Audit Log | `/audit` | Admin, Auditor | KİMSƏYƏ İCAZƏ YOXDUR |
| Users & Roles | `/users` | Admin | Admin |
